package net.kingborn.erp.wc.model;

import lombok.Data;

@Data
public class stu {
}
