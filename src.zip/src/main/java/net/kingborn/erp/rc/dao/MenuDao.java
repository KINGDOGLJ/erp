package net.kingborn.erp.rc.dao;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import net.kingborn.erp.rc.model.Menu;
import org.springframework.stereotype.Component;

@Component
public interface MenuDao extends BaseMapper<Menu> {


}
