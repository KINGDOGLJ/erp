package net.kingborn.erp.sc.model;

import lombok.Data;

@Data
public class echart {
    private String name; //商品名称
    private String quantity; //商品数量
}