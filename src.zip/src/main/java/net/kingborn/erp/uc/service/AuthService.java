package net.kingborn.erp.uc.service;

public interface AuthService {
}
