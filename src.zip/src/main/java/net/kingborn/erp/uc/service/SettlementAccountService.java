package net.kingborn.erp.uc.service;

import com.baomidou.mybatisplus.extension.service.IService;
import net.kingborn.erp.uc.model.SettlementAccount;

import java.util.List;

/**
 * 结算账户服务
 */
public interface SettlementAccountService extends IService<SettlementAccount> {

}
