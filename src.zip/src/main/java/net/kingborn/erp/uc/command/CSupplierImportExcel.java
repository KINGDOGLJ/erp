package net.kingborn.erp.uc.command;

import net.kingborn.core.command.BaseCommand;
import net.kingborn.core.command.Command;

/**
 * 导入Excel
 */
@Command
public class CSupplierImportExcel extends BaseCommand {
    @Override
    protected void init() throws Exception {

    }

    @Override
    protected void doCommand() throws Exception {

    }
}
