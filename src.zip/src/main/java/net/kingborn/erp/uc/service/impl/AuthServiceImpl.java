package net.kingborn.erp.uc.service.impl;

import net.kingborn.erp.uc.service.AuthService;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService {
}
